# Aplicació Django Ninja mínima

Aquesta aplicació serveix com a exemple per aprendre a construir imatges Docker amb Dockerfile. Consisteix en una API REST mínima construïda amb [Django Ninja](https://django-ninja.dev/) i servida amb [Uvicorn](https://www.uvicorn.org/).

## Estructura del projecte

```
myapi/
├── Dockerfile          # Instruccions per construir la imatge
├── .dockerignore       # Fitxers a excloure del context de construcció
├── requirements.txt    # Dependències de Python
├── manage.py           # Utilitat de línia de comandes de Django
└── myapi/
    ├── __init__.py     # Marca el directori com a paquet Python
    ├── api.py          # Definició dels endpoints de l'API
    ├── asgi.py         # Punt d'entrada per a Uvicorn
    ├── settings.py     # Configuració de Django
    └── urls.py         # Configuració de rutes URL
```

## Endpoints disponibles

| Mètode | Ruta | Descripció |
|--------|------|------------|
| GET | `/api/health` | Comprova l'estat del servei |
| GET | `/api/hello` | Retorna un missatge de salutació |

## Construcció i execució

Per construir la imatge:

```bash
docker build --tag myapi:1.0 .
```

Per executar el contenidor:

```bash
docker run --name myapi --publish 8000:8000 --detach myapi:1.0
```

Per provar l'API:

```bash
curl http://localhost:8000/api/health
curl http://localhost:8000/api/hello
```

## Documentació automàtica

Django Ninja genera automàticament documentació interactiva de l'API. Un cop el contenidor estigui en execució, pots accedir-hi a:

- Swagger UI: http://localhost:8000/api/docs
- ReDoc: http://localhost:8000/api/redoc
