"""
Configuració mínima de Django per a l'exemple de Docker.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
# En producció, aquesta clau s'hauria de llegir d'una variable d'entorn.
SECRET_KEY = "django-insecure-exemple-nomes-per-desenvolupament"

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.auth",
    "ninja",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.middleware.common.CommonMiddleware",
]

ROOT_URLCONF = "myapi.urls"

WSGI_APPLICATION = "myapi.wsgi.application"
ASGI_APPLICATION = "myapi.asgi.application"

# Desactivem la base de dades per simplificar l'exemple
DATABASES = {}

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Internacionalització
LANGUAGE_CODE = "ca"
TIME_ZONE = "Europe/Madrid"
USE_I18N = True
USE_TZ = True
