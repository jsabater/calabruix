"""
Configuració ASGI per a l'aplicació myapi.

Uvicorn utilitza aquest fitxer com a punt d'entrada.
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myapi.settings")

application = get_asgi_application()
