from ninja import NinjaAPI

api = NinjaAPI()


@api.get("/health")
def health(request):
    """Endpoint per comprovar l'estat del servei."""
    return {"status": "ok"}


@api.get("/hello")
def hello(request):
    """Endpoint de prova que retorna un missatge de salutació."""
    return {"message": "Hola des de Django Ninja!"}
